# Decision Log

## Status legend

- Accepted: ユーザーが明示した確定事項
- Proposed: 勝つための設計案。ユーザー承認前
- Open: 未決事項

| ID | Status | 決定・論点 | 理由・備考 |
|---|---|---|---|
| D001 | Accepted | 新入生と部活・サークルをマッチングする | ゼミ課題 |
| D002 | Accepted | スマートフォン向けWebアプリ | ユーザー指定 |
| D003 | Accepted | 団体側から新入生へオファー・案内を届ける | 従来の自発応募の心理的障壁を下げる |
| D004 | Accepted | 新入生は興味分野を事前登録する | アウトドア等の関心に基づく配信 |
| D005 | Accepted | GitHubを正本として使う | CodexとClaudeの知識を共有する |
| D006 | Accepted | Claude Maxを利用できる | Claude Code等を使用可能 |
| D007 | Proposed | 団体には学生個人一覧を見せず、集計条件へ配信する | 差別・プライバシー・スパム対策 |
| D008 | Proposed | 学生が受信カテゴリと週間上限を設定する | 招待の気軽さと利用者制御の両立 |
| D009 | Proposed | 返答は3段階にする | 断りづらさを下げる |
| D010 | Proposed | 初期マッチングは説明可能なルールベース | デモの安定性と説明性 |
| D011 | Proposed | ワーキングタイトルは「CUE」 | 「参加のきっかけが届く」を表現 |
| D012 | Accepted | Vite + React + TypeScript + localStorage + Vitest | 数日で安定した静的デモを作る |
| D013 | Accepted | 2026年8月22日（土）までにデモ版完成 | メンバー間で持ち寄る |
| D014 | Accepted | ゼミメンバーが各自の成果物を持ち寄って比較する | 動作と第一印象が重要。詳細な採点表は不明 |
| D015 | Open | 神戸大学固有か汎用デモか | データと表現に影響 |
| D016 | Proposed | GitHub Pagesで共有URLを用意する | 持ち寄り時の再現性を高める |
| D017 | Accepted | 認証・本番DB・実通知はデモ対象外 | コア体験の完成度を優先する |
| D018 | Proposed | 架空大学・架空団体のデモデータを使う | 実在団体との混同を防ぐ |
